package com.votingManagementSystem.DTO;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class AdminDTO {
	@Id
	@NotNull(message = "Email cannot be null")
	@Size(min = 8, message = "Email should be of min 8 chars")
	private String email;
	
	@NotNull(message="contact is mandatory")
	private String contact;

	public AdminDTO(String email, @NotNull(message = "contact is mandatory") String contact) {
		super();
		this.email = email;
		this.contact = contact;
	}

	public AdminDTO() {
		super();
	}

	@Override
	public String toString() {
		return "AdminEntity [email= abd@gmail.com, password= Pass#12]";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	
	


}
