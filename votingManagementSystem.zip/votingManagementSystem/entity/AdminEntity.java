package com.votingManagementSystem.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="loginAdmin")
@AllArgsConstructor
@Data
@NoArgsConstructor

public class AdminEntity {
	@Id
	private String EmailId;
	private String Password;
	
	
	
	public void getEmailId() {
		// TODO Auto-generated method stub
		return;
	}
	
	
	
	public void getPassword() {
		// TODO Auto-generated method stub
		return;
	}



	public void setEmail(String id) {
		// TODO Auto-generated method stub
		
	}
	

}
