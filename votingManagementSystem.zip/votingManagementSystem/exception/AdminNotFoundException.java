package com.votingManagementSystem.exception;

public class AdminNotFoundException extends Exception {

	public AdminNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
