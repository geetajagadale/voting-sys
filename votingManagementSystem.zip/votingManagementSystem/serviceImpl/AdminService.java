package com.votingManagementSystem.serviceImpl;

import java.util.List;


import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.votingManagementSystem.entity.AdminEntity;
import com.votingManagementSystem.exception.AdminNotFoundException;



public interface AdminService {
public List<Admin> getAllAdmin();
	
	public Admin getAdmin(String id) throws AdminNotFoundException;
	
	public AdminEntity addAdmin(AdminEntity adminEntity) throws AdminNotFoundException ;
	
	public Admin deleteAdmin(String id) throws AdminNotFoundException;
	
	public AdminEntity updateAdmin(String id, AdminEntity adminEntity) throws AdminNotFoundException;

}
