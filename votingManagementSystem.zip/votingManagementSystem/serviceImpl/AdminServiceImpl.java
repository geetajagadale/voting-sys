package com.votingManagementSystem.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.votingManagementSystem.entity.AdminEntity;
import com.votingManagementSystem.exception.AdminNotFoundException;
import com.votingManagementSystem.repository.AdminRepository;


@Service("adminService")
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRepo;
	
	@Override
	public List<Admin> getAllAdmin() {
		return adminRepo.findAll();
	}

	@Override
	public Admin getAdmin(String id) throws AdminNotFoundException {
		try {
			Optional<Admin> adminData = adminRepo.findById(id);
			if(!adminData.isEmpty()) {
				return adminRepo.findById(id).get();
			}
			else {
				throw new AdminNotFoundException("Admin Data not found");
			}
		}
		catch(Exception e){
			throw new AdminNotFoundException("Admin Data not found");
		}	
	}

	@Override
	public AdminEntity addAdmin(AdminEntity adminEntity)throws AdminNotFoundException{
		// TODO Auto-generated method stub
		return adminRepo.save(adminEntity);
	}

	@Override
	public Admin deleteAdmin(String id) throws AdminNotFoundException {

		try {
			Optional<Admin> adminData = adminRepo.findById(id);
			if(!adminData.isEmpty()) {
				adminRepo.deleteById(id);
				return adminData.get();
			}
			else {
				throw new AdminNotFoundException("Admin Data not found");
			}
		}
		catch(Exception e){
			throw new AdminNotFoundException("Admin Data not found");
		}
	}

	@Override
	public AdminEntity updateAdmin(String id, AdminEntity adminEntity) throws AdminNotFoundException {
		try {
			Optional<Admin> adminData = adminRepo.findById(id);
			if(!adminData.isEmpty()) {
				adminEntity.setEmail(id);
				return adminRepo.saveAll(adminEntity);
			}
			else {
				throw new AdminNotFoundException("Admin Data not found");
			}
		}
		catch(Exception e){
			throw new AdminNotFoundException("Admin Data not found");
		}	
	}

}
